"""
URL configuration for ODI project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView


urlpatterns = [
    path('admin/', admin.site.urls),

    #Documentation Endpoints
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),

    #Endpoints
    path('api/auth/', include('athens.urls'), name='Authentication Endpoints'),
    path('api/chat/', include('chat.urls'), name='Chat Endpoints'),
    path('api/notifications/', include('notifications.urls'), name='Notification Endpoints'),
    path('api/dispatch/', include('dispatch.urls'), name='Dispatch Endpoints'),
    path('api/queries/', include('queries.urls'), name='Queries Endpoints'),
    path('api/reports/', include('report.urls'), name='Reports Endpoints'),
    path('api/settings/', include('user_settings.urls'), name='Settings Endpoints'),
    path('api/inspections/', include('inspection.urls'), name='Inspection Endpoints'),
    path('api/inspector/', include('inspector.urls'), name='Inspector Endpoints'),
]
